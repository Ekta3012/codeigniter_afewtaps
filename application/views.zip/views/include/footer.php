<!-- footer -->


<div style="padding-left:60px;padding-right:60px;background-color:black;color:#f6f6f6">
<div class="row">
<div class="col-sm-6 col-xs-6 col-md-6">

<p style="font-weight:bold;padding-top:60px;">ABOUT US</p>
<p style="padding-top:10px;padding-bottom:20px;">A startup, aiming to create<br>
disruption in the restaurant technology space…<br>
We believe in connecting customers with<br>
restaurants, on personal terms, making them feel “at home”,<br>
which is the highest value addition a restaurant can achieve…</p>

</div>
<div class="col-sm-6 col-xs-6 col-md-6">

<p style="padding-top:20px;padding-bottom:60px;">
<ul class="pull-right" style="list-style-type:none;">
<li style="font-weight:bold;">Blog</li>
<li style="font-weight:bold;">Feedback</li>
<li style="font-weight:bold;"><a style="color:white" href="<?php echo site_url(); ?>/welcome/career">Career</a></li>
<li style="font-weight:bold;"><a style="color:white" href="<?php echo site_url(); ?>/welcome/privacypolicy">Privacy</a></li>
<li style="font-weight:bold;"><a style="color:white" href="<?php echo site_url(); ?>/welcome/faq">FAQ</a></li>
<li style="font-weight:bold;"><a style="color:white" href="<?php echo site_url(); ?>/welcome/terms">Terms</a></li>


</ul>



</p>


</div>

<p class="pull-right" style="color:#00AAAA;">Copyright © 2017 Think Different Technologies (P) Ltd</p>

</div>

</div>





<!-- end of footer -->	
	
	<!-- all scripts -->
	
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.1.1.js"></script>
	
	 <script type="text/javascript" src="assets/js/bootstrap.min.js"></script> 
   
	 <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>  
	 <script  type="text/javascript" src="assets/js/main.js"></script>  
	<script  type="text/javascript" src="assets/js/Carousel.js"></script>
     <script type="text/javascript" src="assets/js/cust.js"></script>  

	<!-- end of scripts -->
    </body>

</html>
