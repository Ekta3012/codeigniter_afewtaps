<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" href="images/Logo2.png" type="image/png" />
<!-- all the meta tags -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- end of all the meta tags -->

<title>afewtaps</title>
<base href="<?php echo base_url(); ?>" />
<!-- the stylesheets -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/animate.css" >
   

	<!-- the fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">
	
	<!-- the fonts -->
	
	<!-- Optional Bootstrap theme -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">
<!-- end of all the stylesheets -->

</head>