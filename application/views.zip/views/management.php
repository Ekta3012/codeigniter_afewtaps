<?php

$this->load->view('include/header.php');

?>

<body>



<!-- 16 slide -->

<div id="fifteen_sixteenseventeen" class="animated fadeInDown" style="color:#161616;padding-top:70px;"> 
<div style="padding-left:60px;padding-right:60px;">
<img src="images/left_circle.png" class="img-responsive center-block" style="cursor:pointer;" onclick="history.back(-1)" />
<p class="text-center animate fadeInDown" style="font-size:50px;padding-top:40px;"><span class="theotherheadingsreponsive">Management Dashboard</span></p>
<p class="text-center animate fadeInDown" style="font-size:20px;">Handling operations. Works on any browser.</p>

<ul style="padding-top:60px;padding-bottom:20px;font-size:14px;color:#161616;">
<li class="animate fadeInDown">View real-time operations, orders, history, payments settlements and cancelled orders.</li>
<li class="animate fadeInDown">Modify menu items, pricing, descriptions, staff employed, taxes.</li>
<li class="animate fadeInDown">Set Restaurant Threshold Limit</li>
<li class="animate fadeInDown">Enter discounts/offers for customers</li>

</ul>

<div class="row">
 <div class="col-md-6">
  <img src="images/deskpic.png" class="img-responsive animate fadeInDown">
 
 </div>
 <div class="col-md-6">
 <ul style="padding-top:130px;font-size:14px;" >
<li class="animate fadeInDown">Business Analytics</li>
<li class="animate fadeInDown">Floor Performance (Staff Analytics)</li>


</ul>
 
 </div>
 

</div>

	
</div>
</div>


<!-- end of 16 slide -->	








<?php


$this->load->view('include/footer.php');


?>
