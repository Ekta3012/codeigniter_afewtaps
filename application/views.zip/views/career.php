<?php

$this->load->view('include/header.php');

?>

<body>


<div  style="padding-left:30px;padding-right:30px;padding-top:30px;padding-bottom:60px;background-image:url('images/career.jpg');color:white;background-size:cover;height:900px;">
<a href="<?php echo site_url(); ?>/welcome/index"><img src="images/left_circle.png" class="img-responsive center-block" style="cursor:pointer;padding-top:20px;" /></a>
<p class="text-center animated fadeInDown careertextsmall" style="font-size:50px;letter-spacing: -0.024em;padding-top:20px;"><span class="theotherheadingsreponsive">Job Opportunity</span></p>
<p class="text-center animated fadeInDown" style="font-size:22px;letter-spacing: -0.024em;">Be known for the change</p>

<img src="images/star2.png" class="img-responsive center-block" style="padding-top:60px;padding-bottom:60px;"/>

<p class="text-center animated fadeInDown careertextsmall" style="font-size:50px;letter-spacing: -0.024em;">We’re always in the hunt for talent…</p>

<p class="text-center animated fadeInDown" style="font-size:22px;letter-spacing: -0.024em;">Join us if you feel you can make a difference</p>

<p class="pull-right animated fadeInDown" style="font-size:22px;letter-spacing: -0.024em;padding-top:100px;">Send us your details at <span style="font-weight:bold;"><a href="mailto:info@afewtaps.com">info@afewtaps.com</a></span></p>


</div>




<?php


$this->load->view('include/footer.php');


?>
